import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialIcons } from '@expo/vector-icons';
import { createTables } from './screens/database';
import SplashScreen from './screens/SplashScreen'; 
import LoginScreen from './screens/LoginScreen';
import SignUpScreen from './screens/SignUpScreen';
import AdminSignUp from './screens/adminScreens/AdminSignUp';
import VolunteerSignUp from './screens/VoluntarioScreens/VolunteerSignUp';
import EscalasScreen from './screens/adminScreens/EscalasScreen';
import EventoScreen from './screens/adminScreens/EventoScreen';
import PessoasScreen from './screens/adminScreens/PessoasScreen';
import CadastrarEscala from './screens/adminScreens/CadastrarEscala';
import DepartmentsScreen from './screens/adminScreens/DepartmentsScreen';
import PerfilAdmin from './screens/adminScreens/PerfilAdmin';
import PerfilVolunteer from './screens/VoluntarioScreens/PerfilVolunteer';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Dashboard do Admin com o menu inferior
function AdminDashboardTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;

          switch (route.name) {
            case 'Escalas':
              iconName = 'list';
              break;
            case 'Eventos':
              iconName = 'event';
              break;
            case 'Voluntários':
              iconName = 'group';
              break;
            case 'Departamentos':
              iconName = 'folder';
              break;
            case 'PerfilAdmin':
              iconName = 'person';
              break;
            default:
              iconName = 'help';
          }

          return <MaterialIcons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: 'tomato',
        tabBarInactiveTintColor: 'gray',
        headerShown: false,  // Remove o cabeçalho do Tab.Navigator
      })}
    >
      <Tab.Screen name="Escalas" component={EscalasScreen} options={{ title: 'Escalas' }} />
      <Tab.Screen name="Eventos" component={EventoScreen} options={{ title: 'Eventos' }} />
      <Tab.Screen name="Voluntários" component={PessoasScreen} options={{ title: 'Voluntários' }} />
      <Tab.Screen name="Departamentos" component={DepartmentsScreen} options={{ title: 'Departamentos' }} />
      <Tab.Screen name="PerfilAdmin" component={PerfilAdmin} options={{ title: 'Perfil' }} />
    </Tab.Navigator>
  );
}

// Dashboard do Voluntário com o menu inferior
function VolunteerDashboardTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;

          switch (route.name) {
            case 'PerfilVolunteer':
              iconName = 'person';
              break;
            default:
              iconName = 'help';
          }

          return <MaterialIcons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: 'tomato',
        tabBarInactiveTintColor: 'gray',
        headerShown: false,  // Remove o cabeçalho do Tab.Navigator
      })}
    >
      <Tab.Screen name="PerfilVolunteer" component={PerfilVolunteer} options={{ title: 'Perfil' }} />
    </Tab.Navigator>
  );
}

export default function App() {
  useEffect(() => {
    createTables(); // Inicializa as tabelas no banco de dados SQLite
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Splash">
        <Stack.Screen 
          name="Splash" 
          component={SplashScreen} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="LoginScreen" 
          component={LoginScreen} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="SignUpScreen" 
          component={SignUpScreen} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="AdminSignUp" 
          component={AdminSignUp} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="VolunteerSignUp" 
          component={VolunteerSignUp} 
          options={{ headerShown: false }} 
        />
        {/* Dashboard do Admin */}
        <Stack.Screen 
          name="AdminDashboard" 
          component={AdminDashboardTabs} 
          options={{ headerShown: false }} 
        />
        {/* Dashboard do Voluntário */}
        <Stack.Screen 
          name="VolunteerDashboard" 
          component={VolunteerDashboardTabs} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="CadastrarEscala" 
          component={CadastrarEscala} 
          options={{ headerShown: true }} 
        />
        <Stack.Screen 
          name="DepartmentsScreen" 
          component={DepartmentsScreen} 
          options={{ headerShown: true }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
