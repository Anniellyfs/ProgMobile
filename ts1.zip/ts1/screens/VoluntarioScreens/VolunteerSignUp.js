import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ScrollView, TouchableOpacity } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { insertUser, getDepartments } from '../database';
 

export default function VoluteerSignUp({ route, navigation }) {
  // Definindo um valor padrão para userType, caso não seja passado
  const userType = route?.params?.userType || 'Admin'
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [selectedDepartments, setSelectedDepartments] = useState([]);
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    getDepartments((data) => {
      setDepartments(data);
    });
  }, []);

  const handleSignUp = () => {
    // Verifica se todos os campos estão preenchidos
    if (!name || !email || !password || !confirmPassword) {
      console.log('Preencha todos os campos'); // Log para depuração
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    // Verifica se as senhas coincidem
    if (password !== confirmPassword) {
      console.log('Senhas não coincidem'); // Log para depuração
      Alert.alert('Erro', 'As senhas não coincidem.');
      return;
    }
    
     // Chama a função insertUser passando todos os parâmetros necessários
    console.log('Chamando insertUser com:', email, password, userType); // Log para depuração
    insertUser(email, password, userType, (result) => {
      console.log('Usuário inserido com sucesso:', result); // Log para depuração
      Alert.alert(
        'Sucesso', 
        'Usuário cadastrado com sucesso', 
        [
          { text: 'OK', onPress: () => navigation.navigate('LoginScreen') }
        ]
      );
    });
  };


  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Cadastro de Voluntário</Text>
      <TextInput
        style={styles.input}
        placeholder="Nome"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <TextInput
        style={styles.input}
        placeholder="Confirmar Senha"
        value={confirmPassword}
        onChangeText={setConfirmPassword}
        secureTextEntry
      />
      <Text>Departamentos:</Text>
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={null}
          onValueChange={(itemValue) => {
            if (itemValue) {
              setSelectedDepartments(prevDepartments => {
                if (prevDepartments.includes(itemValue)) {
                  return prevDepartments.filter(id => id !== itemValue);
                } else {
                  return [...prevDepartments, itemValue];
                }
              });
            }
          }}
          style={styles.input}
          mode="dropdown"
        >
          <Picker.Item label="Selecione os departamentos" value={null} />
          {departments.map((dept) => (
            <Picker.Item key={dept.id} label={dept.name} value={dept.id} />
          ))}
        </Picker>
      </View>
      <View style={styles.selectedDepartments}>
        {selectedDepartments.map(id => {
          const department = departments.find(dept => dept.id === id);
          return department ? <Text key={id} style={styles.selectedDepartment}>{department.name}</Text> : null;
        })}
      </View>
      <Button title="Cadastrar" onPress={handleSignUp} />
      
      {/* Botão Voltar */}
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <Text style={styles.backButtonText}>Voltar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  pickerContainer: {
    marginBottom: 20,
  },
  selectedDepartments: {
    marginBottom: 20,
  },
  selectedDepartment: {
    fontSize: 16,
    color: 'black',
    marginVertical: 5,
  },
  backButton: {
    marginTop: 20,
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 18,
    color: 'blue',
  },
});
