import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { getSchedulesForVolunteer } from '../database';

const ProfilVolunteer = ({ volunteerId }) => {
  const [scheduleData, setScheduleData] = useState([]);

  useEffect(() => {
    getSchedulesForVolunteer(volunteerId, setScheduleData);
  }, [volunteerId]);

  const renderRoleItem = ({ item }) => (
    <View style={styles.roleItem}>
      <View style={styles.roleTextContainer}>
        <Text style={styles.roleText}>{item.role}</Text>
        <Text style={styles.roleTime}>{item.time}</Text>
      </View>
      <TouchableOpacity>
        <FontAwesome name="check-circle" size={24} color="green" />
      </TouchableOpacity>
    </View>
  );

  const renderScheduleItem = ({ item }) => (
    <View style={styles.scheduleItem}>
      <Text style={styles.dateText}>{item.date}</Text>
      <Text style={styles.serviceText}>{item.department}</Text>
      <FlatList
        data={[item]} // Como o voluntário tem um papel específico por escala, passamos o item como array
        renderItem={renderRoleItem}
        keyExtractor={(role) => role.role}
      />
      <View style={styles.actionButtons}>
        <TouchableOpacity style={styles.splitButton}>
          <Text style={styles.splitText}>SPLIT</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.declineButton}>
          <Text style={styles.declineText}>DECLINE...</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.acceptButton}>
          <Text style={styles.acceptText}>ACCEPT</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Minhas Escalas</Text>
        <TouchableOpacity>
          <FontAwesome name="bell" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity>
          <FontAwesome name="user-circle" size={24} color="black" />
        </TouchableOpacity>
      </View>
      <FlatList
        data={scheduleData}
        renderItem={renderScheduleItem}
        keyExtractor={(item) => `${item.date}-${item.department}`}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 30,
  },
  scheduleItem: {
    backgroundColor: '#fff',
    margin: 16,
    borderRadius: 8,
    padding: 16,
  },
  dateText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  serviceText: {
    fontSize: 16,
    color: '#666',
    marginVertical: 8,
  },
  roleItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
  roleTextContainer: {
    flex: 1,
    marginLeft: 16,
  },
  roleText: {
    fontSize: 16,
  },
  roleTime: {
    fontSize: 14,
    color: '#666',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  splitButton: {
    padding: 8,
    backgroundColor: '#ddd',
    borderRadius: 4,
  },
  splitText: {
    color: '#333',
  },
  declineButton: {
    padding: 8,
    backgroundColor: '#ff5c5c',
    borderRadius: 4,
  },
  declineText: {
    color: '#fff',
  },
  acceptButton: {
    padding: 8,
    backgroundColor: '#4caf50',
    borderRadius: 4,
  },
  acceptText: {
    color: '#fff',
  },
});

export default ProfilVolunteer;
