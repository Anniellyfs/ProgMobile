import React, { useState } from 'react';
import { View, Text, Button, TouchableOpacity, StyleSheet, Alert } from 'react-native';

export default function SignUpScreen({ navigation }) {
  const [userType, setUserType] = useState(null);

  const handleUserTypeSelection = (type) => {
    setUserType(type);
  };

  const handleProceed = () => {
    if (userType) {
      switch (userType) {
        case 'Admin':
          navigation.navigate('AdminSignUp', { userType });
          break;
        case 'Volunteer':
          navigation.navigate('VolunteerSignUp', { userType });
          break;
        default:
          Alert.alert('Selecione um tipo de usuário');
      }
    } else {
      Alert.alert('Selecione um tipo de usuário');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logoText}>Cadastrar</Text>
      <Text style={styles.label}>Selecione sua categoria</Text>
      
      <TouchableOpacity 
        style={[styles.userTypeButton, userType === 'Admin' && styles.selectedButton]}
        onPress={() => handleUserTypeSelection('Admin')}>
        <Text style={styles.userTypeText}>Administrador</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={[styles.userTypeButton, userType === 'Volunteer' && styles.selectedButton]}
        onPress={() => handleUserTypeSelection('Volunteer')}>
        <Text style={styles.userTypeText}>Voluntário</Text>
      </TouchableOpacity>

      <Button title="Continuar" onPress={handleProceed} />
      <TouchableOpacity onPress={() => navigation.navigate('LoginScreen')} style={styles.loginButton}>
        <Text style={styles.loginText}>Já tem conta? Login</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#f5f5f5',
  },
  logoText: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 30,
  },
  label: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
  userTypeButton: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
  },
  selectedButton: {
    backgroundColor: '#052b4e',
  },
  userTypeText: {
    fontSize: 16,
    color: '#000',
  },
  loginText: {
    textAlign: 'center',
    color: '#0000EE',
    marginTop: 20,
  },
});
