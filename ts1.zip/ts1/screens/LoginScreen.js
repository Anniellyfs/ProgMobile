import React, { useState } from 'react';
import { View, TextInput, Button, Text, TouchableOpacity, StyleSheet, Image, Alert } from 'react-native';
import * as SQLite from 'expo-sqlite/legacy';

const db = SQLite.openDatabase('church.db');

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (!email || !password) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    db.transaction(tx => {
      tx.executeSql(
        'SELECT * FROM users WHERE email = ? AND password = ?',
        [email, password],
        (tx, results) => {
          if (results.rows.length > 0) {
            const user = results.rows.item(0);
            if (user.userType === 'Admin') {
              // Navegar para o Dashboard do Admin
              navigation.replace('AdminDashboard');
            } else if (user.userType === 'Volunteer') {
              // Navegar para a tela de perfil de voluntário
              navigation.replace('VolunteerDashboard'); // Atualize para a tela de Dashboard do Volunteer
            } else {
              Alert.alert('Erro', 'Tipo de usuário desconhecido.');
            }
          } else {
            Alert.alert('Erro', 'Email ou senha inválidos.');
          }
        },
        (tx, error) => {
          console.error('Erro ao processar o login:', error);
          Alert.alert('Erro', 'Erro ao processar o login. Tente novamente mais tarde.');
        }
      );
    });
  };

  return (
    <View style={styles.container}>
      <Image source={require('../assets/icon1.png')} style={styles.icon} resizeMode='contain' />
      <Text style={styles.label}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType='email-address'
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <View style={styles.buttonContainer}>
        <Button title="Entrar" onPress={handleLogin} />
      </View>
      <TouchableOpacity onPress={() => navigation.navigate('SignUpScreen')}>
        <Text style={styles.signupText}>Não tem uma conta? Cadastrar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#f5f5f5',
  },
  icon: {
    width: 150,
    height: 150,
    marginBottom: 20,
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
  },
  input: {
    width: '100%',
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  buttonContainer: {
    width: '100%',
    marginBottom: 10,
  },
  signupText: {
    textAlign: 'center',
    color: '#0000EE',
  },
});

export default LoginScreen;
