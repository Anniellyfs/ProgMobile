import * as SQLite from 'expo-sqlite/legacy';

// Abrir o banco de dados
const db = SQLite.openDatabase('church.db');

// Função para criar as tabelas e adicionar colunas se necessário
export const createTables = () => {
  db.transaction(tx => {
    // Tabela de usuários
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        userType TEXT NOT NULL
      );`,
      [],
      () => console.log('Tabela de usuários verificada/criada com sucesso'),
      (tx, error) => console.log('Erro ao criar/verificar tabela de usuários: ', error)
    );

    // Tabela de departamentos
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL
      );`,
      [],
      () => console.log('Tabela de departamentos verificada/criada com sucesso'),
      (tx, error) => console.log('Erro ao criar tabela de departamentos: ', error)
    );

    // Tabela de escalas
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        department TEXT NOT NULL,
        volunteers TEXT NOT NULL,
        observations TEXT
      );`,
      [],
      () => console.log('Tabela de escalas verificada/criada com sucesso'),
      (tx, error) => console.log('Erro ao criar tabela de escalas: ', error)
    );

    // Tabela de voluntários
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS volunteers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        userId INTEGER,
        FOREIGN KEY(userId) REFERENCES users(id)
      );`,
      [],
      () => console.log('Tabela de voluntários verificada/criada com sucesso'),
      (tx, error) => console.log('Erro ao criar tabela de voluntários: ', error)
    );

    // Tabela de associação entre voluntários e departamentos
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS volunteer_departments (
        volunteerId INTEGER,
        departmentId INTEGER,
        FOREIGN KEY(volunteerId) REFERENCES volunteers(id),
        FOREIGN KEY(departmentId) REFERENCES departments(id),
        PRIMARY KEY (volunteerId, departmentId)
      );`,
      [],
      () => console.log('Tabela de associação entre voluntários e departamentos verificada/criada com sucesso'),
      (tx, error) => console.log('Erro ao criar tabela de associação entre voluntários e departamentos: ', error)
    );

    // Tabela de associação entre voluntários e escalas
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS volunteer_schedules (
        volunteerId INTEGER,
        scheduleId INTEGER,
        role TEXT NOT NULL,
        FOREIGN KEY(volunteerId) REFERENCES volunteers(id),
        FOREIGN KEY(scheduleId) REFERENCES schedules(id),
        PRIMARY KEY (volunteerId, scheduleId, role)
      );`,
      [],
      () => console.log('Tabela de associação entre voluntários e escalas verificada/criada com sucesso'),
      (tx, error) => console.log('Erro ao criar tabela de associação entre voluntários e escalas: ', error)
    );
  });
};

// Função para inserir um novo usuário com o tipo de usuário
export const insertUser = (email, password, userType, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      `INSERT INTO users (email, password, userType) VALUES (?, ?, ?);`,
      [email, password, userType],
      (_, result) => callback(result),
      (tx, error) => console.log('Erro ao inserir usuário: ', error)
    );
  });
};

// Função para verificar o login do usuário
export const verifyLogin = (email, password, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      `SELECT * FROM users WHERE email = ? AND password = ?;`,
      [email, password],
      (_, { rows: { _array } }) => {
        callback(_array.length > 0);
      },
      (tx, error) => {
        console.log('Erro ao verificar login: ', error);
        callback(false);
      }
    );
  });
};

// Função para inserir um novo voluntário
export const insertVolunteer = (name, email, userId, departments, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'INSERT INTO volunteers (name, email, userId) VALUES (?, ?, ?);',
      [name, email, userId],
      (_, result) => {
        const volunteerId = result.insertId;
        if (volunteerId) {
          let departmentInsertions = 0;
          departments.forEach(departmentId => {
            tx.executeSql(
              'INSERT INTO volunteer_departments (volunteerId, departmentId) VALUES (?, ?);',
              [volunteerId, departmentId],
              () => {
                departmentInsertions++;
                if (departmentInsertions === departments.length) {
                  callback(result);
                }
              },
              (tx, error) => console.log('Erro ao associar voluntário ao departamento: ', error)
            );
          });
        } else {
          console.log('Erro: volunteerId não foi gerado.');
        }
      },
      (tx, error) => console.log('Erro ao inserir voluntário: ', error)
    );
  });
};

// Função para inserir um novo departamento
export const insertDepartment = (name, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'INSERT INTO departments (name) VALUES (?);',
      [name],
      (_, result) => callback(result),
      (tx, error) => console.log('Erro ao inserir departamento: ', error)
    );
  });
};

// Função para inserir uma nova escala
export const insertSchedule = (date, time, department, volunteers, observations, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'INSERT INTO schedules (date, time, department, volunteers, observations) VALUES (?, ?, ?, ?, ?);',
      [date, time, department, volunteers, observations],
      (_, result) => callback(result),
      (tx, error) => console.log('Erro ao inserir escala: ', error)
    );
  });
};

// Função para associar um voluntário a uma escala
export const insertVolunteerSchedule = (volunteerId, scheduleId, role, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'INSERT INTO volunteer_schedules (volunteerId, scheduleId, role) VALUES (?, ?, ?);',
      [volunteerId, scheduleId, role],
      (_, result) => callback(result),
      (tx, error) => console.log('Erro ao associar voluntário à escala: ', error)
    );
  });
};

// Função para buscar todos os departamentos
export const getDepartments = (callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'SELECT * FROM departments;',
      [],
      (_, { rows: { _array } }) => callback(_array),
      (tx, error) => console.log('Erro ao buscar departamentos: ', error)
    );
  });
};

// Função para buscar todos os voluntários com seus departamentos e escalas
export const getVolunteers = (callback) => {
  db.transaction(tx => {
    tx.executeSql(
      `SELECT v.id, v.name, v.email, GROUP_CONCAT(DISTINCT d.name) AS departments, GROUP_CONCAT(DISTINCT s.date || ' ' || s.time || ' ' || vs.role) AS schedules
       FROM volunteers v
       LEFT JOIN volunteer_departments vd ON v.id = vd.volunteerId
       LEFT JOIN departments d ON vd.departmentId = d.id
       LEFT JOIN volunteer_schedules vs ON v.id = vs.volunteerId
       LEFT JOIN schedules s ON vs.scheduleId = s.id
       GROUP BY v.id;`,
      [],
      (_, { rows: { _array } }) => callback(_array),
      (tx, error) => console.log('Erro ao buscar voluntários: ', error)
    );
  });
};

// Função para buscar usuários por tipo de usuário
export const getUsersByType = (userType, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'SELECT * FROM users WHERE userType = ?;',
      [userType],
      (_, { rows: { _array } }) => callback(_array),
      (tx, error) => console.log('Erro ao buscar usuários por tipo: ', error)
    );
  });
};

// Função para obter as escalas de um voluntário
export const getSchedulesForVolunteer = (volunteerId, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      `SELECT s.*
       FROM schedules s
       INNER JOIN volunteer_schedules vs ON s.id = vs.scheduleId
       WHERE vs.volunteerId = ?;`,
      [volunteerId],
      (_, { rows: { _array } }) => callback(_array),
      (tx, error) => {
        console.log('Erro ao buscar escalas para o voluntário: ', error);
        callback([]); // Retorna um array vazio em caso de erro
      }
    );
  });
};
