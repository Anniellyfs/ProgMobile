import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet, FlatList, Alert, TextInput } from 'react-native';
import { getDepartments, insertDepartment, updateDepartment, deleteDepartment } from '../database';

const DepartamentosScreen = () => {
  const [departments, setDepartments] = useState([]);
  const [newDepartment, setNewDepartment] = useState('');
  const [editing, setEditing] = useState(null);
  const [editedName, setEditedName] = useState('');

  useEffect(() => {
    getDepartments((data) => {
      setDepartments(data);
    });
  }, []);

  const handleAdd = () => {
    if (!newDepartment) {
      Alert.alert('Erro', 'Digite o nome do departamento.');
      return;
    }
    insertDepartment(newDepartment, () => {
      setNewDepartment('');
      getDepartments((data) => {
        setDepartments(data);
      });
    });
  };

  const handleEdit = (id, name) => {
    setEditing(id);
    setEditedName(name);
  };

  const handleUpdate = () => {
    if (!editedName) {
      Alert.alert('Erro', 'Digite o novo nome do departamento.');
      return;
    }
    updateDepartment(editing, editedName, () => {
      setEditing(null);
      setEditedName('');
      getDepartments((data) => {
        setDepartments(data);
      });
    });
  };

  const handleDelete = (id) => {
    Alert.alert('Confirmar', 'Tem certeza que deseja excluir este departamento?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Excluir', onPress: () => {
        deleteDepartment(id, () => {
          getDepartments((data) => {
            setDepartments(data);
          });
        });
      }},
    ]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerenciar Departamentos</Text>

      <TextInput
        style={styles.input}
        placeholder="Novo Departamento"
        value={newDepartment}
        onChangeText={setNewDepartment}
      />
      <Button title="Adicionar Departamento" onPress={handleAdd} />

      {editing !== null && (
        <View style={styles.editContainer}>
          <TextInput
            style={styles.input}
            placeholder="Novo Nome"
            value={editedName}
            onChangeText={setEditedName}
          />
          <Button title="Atualizar" onPress={handleUpdate} />
        </View>
      )}

      <FlatList
        data={departments}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.name}</Text>
            <Button title="Editar" onPress={() => handleEdit(item.id, item.name)} />
            <Button title="Excluir" onPress={() => handleDelete(item.id)} color="red" />
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    marginTop: 30,
  },
  input: {
    width: '100%',
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  editContainer: {
    marginBottom: 20,
  },
  item: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default DepartamentosScreen;
