import React, { useEffect, useLayoutEffect, useState } from 'react';
import { View, Text, Button, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { getDepartments } from '../database';
import { MaterialIcons } from '@expo/vector-icons';

const EscalasScreen = ({ navigation }) => {
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    // Buscar os departamentos ao carregar a tela
    getDepartments((data) => {
      setDepartments(data);
    });
  }, []);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity onPress={() => navigation.navigate('AdminProfile')}>
          <MaterialIcons name="person" size={24} color="black" style={{ marginRight: 15 }} />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Escalas Cadastradas</Text>
      <FlatList
        data={departments}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.name}</Text>
          </View>
        )}
      />
      <Button
        title="Cadastrar Nova Escala"
        onPress={() => navigation.navigate('CadastrarEscala')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    marginTop: 30,
  },
  item: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
});

export default EscalasScreen;
