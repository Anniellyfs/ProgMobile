import React, { useState } from 'react';
import { View, Text, TextInput, Button, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { insertUser } from '../database';

export default function AdminSignUp({ route, navigation }) {
  // Definindo um valor padrão para userType, caso não seja passado
  const userType = route?.params?.userType || 'Admin';

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSignUp = () => {
    // Verifica se todos os campos estão preenchidos
    if (!name || !email || !password || !confirmPassword) {
      console.log('Preencha todos os campos'); // Log para depuração
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    // Verifica se as senhas coincidem
    if (password !== confirmPassword) {
      console.log('Senhas não coincidem'); // Log para depuração
      Alert.alert('Erro', 'As senhas não coincidem.');
      return;
    }

    // Chama a função insertUser passando todos os parâmetros necessários
    console.log('Chamando insertUser com:', email, password, userType); // Log para depuração
    insertUser(email, password, userType, (result) => {
      console.log('Usuário inserido com sucesso:', result); // Log para depuração
      Alert.alert(
        'Sucesso', 
        'Usuário cadastrado com sucesso', 
        [
          { text: 'OK', onPress: () => navigation.navigate('LoginScreen') }
        ]
      );
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logoText}>Cadastrar Administrador</Text>
      <TextInput
        style={styles.input}
        placeholder="Nome"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TextInput
        style={styles.input}
        placeholder="Confirmar senha"
        secureTextEntry
        value={confirmPassword}
        onChangeText={setConfirmPassword}
      />
      <Button title="Criar" onPress={handleSignUp} />
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <Text style={styles.backText}>Voltar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    backgroundColor: '#f5f5f5',
  },
  logoText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 30,
  },
  input: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  backButton: {
    marginTop: 20,
    alignItems: 'center',
  },
  backText: {
    color: '#0000EE',
  },
});
