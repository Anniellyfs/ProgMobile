import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, Platform } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { getDepartments, saveSchedule, getVolunteers } from '../database';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const CadastrarEscala = ({ navigation }) => {
  const [date, setDate] = useState(new Date());
  const [time, setTime] = useState(new Date());
  const [department, setDepartment] = useState('');
  const [volunteers, setVolunteers] = useState([]);
  const [selectedVolunteers, setSelectedVolunteers] = useState([]);
  const [observations, setObservations] = useState('');
  const [departments, setDepartments] = useState([]);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [dateString, setDateString] = useState('');
  const [timeString, setTimeString] = useState('');

  useEffect(() => {
    getDepartments((data) => {
      setDepartments(data);
    });
    getVolunteers((data) => {
      setVolunteers(data);
    });
  }, []);

  const handleDateChange = (event, selectedDate) => {
    setShowDatePicker(Platform.OS === 'ios');
    if (selectedDate) {
      const formattedDate = format(selectedDate, 'dd/MM/yyyy', { locale: ptBR });
      setDate(formattedDate);
      setDateString(formattedDate);
    }
  };

  const handleTimeChange = (event, selectedTime) => {
    setShowTimePicker(Platform.OS === 'ios');
    if (selectedTime) {
      const hours = selectedTime.getHours().toString().padStart(2, '0');
      const minutes = selectedTime.getMinutes().toString().padStart(2, '0');
      const formattedTime = `${hours}:${minutes}`;
      setTime(formattedTime);
      setTimeString(formattedTime);
    }
  };

  const handleSave = () => {
    if (!date || !time || !department || selectedVolunteers.length === 0) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    const schedule = {
      date,
      time,
      department,
      volunteers: selectedVolunteers,
      observations,
    };

    saveSchedule(schedule, () => {
      Alert.alert('Sucesso', 'Escala salva com sucesso!');
      navigation.goBack();
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cadastrar Escala</Text>

      <Text>Data:</Text>
      <Button title="Escolher Data" onPress={() => setShowDatePicker(true)} />
      {showDatePicker && (
        <DateTimePicker
          value={new Date(date || Date.now())}
          mode="date"
          display="default"
          onChange={handleDateChange}
          locale="pt-BR" // Para o calendário em português (se suportado)
        />
      )}
      <Text>{dateString || 'Nenhuma data selecionada'}</Text>

      <Text>Hora:</Text>
      <Button title="Escolher Hora" onPress={() => setShowTimePicker(true)} />
      {showTimePicker && (
        <DateTimePicker
          value={new Date(`1970-01-01T${time || '00:00'}:00Z`)}
          mode="time"
          display="default"
          onChange={handleTimeChange}
          is24Hour={true} // Define o formato de 24 horas
        />
      )}
      <Text>{timeString || 'Nenhuma hora selecionada'}</Text>

      <Text>Departamento:</Text>
      <Picker
        selectedValue={department}
        onValueChange={(itemValue) => setDepartment(itemValue)}
        style={styles.input}
      >
        <Picker.Item label="Selecione um Departamento" value="" />
        {departments.map((dept) => (
          <Picker.Item key={dept.id} label={dept.name} value={dept.name} />
        ))}
      </Picker>

      <Text>Voluntários alocados:</Text>
      <Picker
        selectedValue={selectedVolunteers}
        onValueChange={(itemValue) => setSelectedVolunteers(itemValue)}
        style={styles.input}
        mode="multiple"
      >
        {volunteers.map((vol) => (
          <Picker.Item key={vol.id} label={vol.name} value={vol.id} />
        ))}
      </Picker>

      <Text>Observações:</Text>
      <TextInput
        style={styles.input}
        placeholder="Observações"
        value={observations}
        onChangeText={setObservations}
      />

      <View style={styles.buttonContainer}>
        <Button title="Salvar" onPress={handleSave} />
        <Button title="Cancelar" onPress={() => navigation.goBack()} color="red" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    width: '100%',
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default CadastrarEscala;
