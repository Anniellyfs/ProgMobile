import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { Calendar } from 'react-native-calendars';
import { getDepartments } from '../database'; // Ajuste o caminho conforme necessário

const EventoScreen = () => {
  const [selectedDate, setSelectedDate] = useState('');
  const [departments, setDepartments] = useState([]);
  const [volunteers, setVolunteers] = useState([]);

  useEffect(() => {
    // Buscar departamentos ao carregar a tela
    getDepartments((data) => {
      setDepartments(data);
    });
    // Você pode adicionar uma função para buscar voluntários se necessário
  }, []);

  return (
    <View style={styles.container}>
      <Calendar
        onDayPress={(day) => setSelectedDate(day.dateString)}
        markedDates={{ [selectedDate]: { selected: true, marked: true, dotColor: 'blue' } }}
      />
      <Text style={styles.title}>Departamentos e Voluntários para o dia selecionado</Text>
      <Text style={styles.subtitle}>Departamentos:</Text>
      <FlatList
        data={departments}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.name}</Text>
          </View>
        )}
      />
      <Text style={styles.subtitle}>Voluntários:</Text>
      {/* Exemplo de lista de voluntários */}
      <FlatList
        data={volunteers} // Atualize com a função para buscar voluntários
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.name}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginVertical: 10,
    marginTop: 30,
  },
  subtitle: {
    fontSize: 18,
    marginVertical: 10,
  },
  item: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
});

export default EventoScreen;
